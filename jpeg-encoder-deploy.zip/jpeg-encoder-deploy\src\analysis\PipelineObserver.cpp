﻿#include "jpegdsp/analysis/PipelineObserver.hpp"

// default implementations in header

