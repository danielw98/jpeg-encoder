﻿#include <iostream>

int main(int argc, char** argv)
{
    (void)argc; (void)argv;
    std::cout << "jpegdsp_dct_demo stub" << std::endl;
    return 0;
}
